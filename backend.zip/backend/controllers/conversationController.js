import ChatSession from "../models/ChatSession.js";
import User from "../models/User.js";
import { encodeMessageForLawGPT } from './lawgptTokenizer.js';
// Send message and store in MongoDB
export const handleMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { message, sessionId, model } = req.body;

    let session;

    if (sessionId && sessionId !== "null" && sessionId !== "undefined") {
      // Find existing session
      session = await ChatSession.findOne({
        _id: sessionId,
        userId: userId
      });

      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
    } else {
      // Create new session if none exists
      session = new ChatSession({
        userId: userId,
        title: message ? message.substring(0, 30) + (message.length > 30 ? "..." : "") : "New Chat"
      });

      // Increment user's totalChats count when a new chat is created
      try {
        await User.findByIdAndUpdate(userId, { $inc: { totalChats: 1 } });
        console.log(`📊 User ${userId} totalChats incremented for new session`);
      } catch (countError) {
        console.error(`❌ Error incrementing totalChats for user ${userId}:`, countError);
        // Don't fail session creation if updating totalChats fails
      }
    }

    let botReply = "";

    // Add user message
    if (message && message.trim() !== "") {
      session.messages.push({
        sender: "user",
        message: message.trim(),
        timestamp: new Date()
      });

      // Generate bot response (replace with your actual AI integration)
      botReply = await generateBotResponse(message, model);

      session.messages.push({
        sender: "bot",
        message: botReply,
        timestamp: new Date()
      });

      // Update session title based on first message if not set
      if (!session.title || session.title === "New Chat") {
        session.title = message.substring(0, 50) + (message.length > 50 ? "..." : "");
      }
    }

    await session.save();

    res.status(200).json({
      session: {
        _id: session._id,
        title: session.title,
        messages: session.messages,
        createdAt: session.createdAt,
        updatedAt: session.updatedAt
      },
      botReply: botReply
    });
  } catch (error) {
    console.error("❌ handleMessage Error:", error);
    res.status(500).json({ error: error.message });
  }
};

// const generateBotResponse = async (message, model = 'LAWGPT-4') => {
//   try {
//     // Define different API endpoints for different models
//     const modelEndpoints = {
//       'LAWGPT-4': "https://consequential-wettable-danika.ngrok-free.dev/generate",
//       'LAWGPT-3.5': "https://consequential-wettable-danika.ngrok-free.dev/generate",
//       'Legal-Pro': "https://consequential-wettable-danika.ngrok-free.dev/generate",
//       'Contract-AI': "https://consequential-wettable-danika.ngrok-free.dev/generate",
//       'LitAssist': "https://consequential-wettable-danika.ngrok-free.dev/generate"
//     };

//     // For now, using the same endpoint for all models
//     // In production, you would have different AI services/endpoints for each model
//     const API_URL = modelEndpoints[model] || modelEndpoints['LAWGPT-4'];

//     console.log(`🔄 Sending request to: ${API_URL} for model: ${model}`);
//     console.log("📤 Message:", message);

//     const response = await fetch(API_URL, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//         "ngrok-skip-browser-warning": "true"  // Skip ngrok warning page
//       },
//       body: JSON.stringify({
//         query: message,
//         model: model // Pass the model to the AI service if it supports it
//       })
//     });

//     console.log("📥 Response status:", response.status);
//     console.log("📥 Response OK:", response.ok);

//     if (!response.ok) {
//       const errorText = await response.text();
//       console.error("❌ Error response:", errorText);
//       throw new Error(`Server error: ${response.status} ${response.statusText}`);
//     }

//     const data = await response.json();
//     console.log("✅ Data received:", data);

//     if (!data.response) {
//       throw new Error("No response from AI model");
//     }

//     return data.response;

//   } catch (error) {
//     console.error("❌ generateBotResponse Error:", error);

//     // More specific error messages
//     if (error.message.includes("Failed to fetch")) {
//       return "⚠️ Cannot connect to AI server. Please check if the server is running.";
//     }

//     return `⚠️ Sorry, I could not process your request: ${error.message}`;
//   }
// };



// Fetch all sessions for the user


// We'll define this

import fetch from 'node-fetch';// Helper to tokenize message

const generateBotResponse = async (message, model = 'LAWGPT-4') => {
  try {
    const modelEndpoints = {
      'LAWGPT-4': "https://consequential-wettable-danika.ngrok-free.dev/generate",
      'LAWGPT-3.5': "https://abhinav777-77-head.hf.space/generate_from_ids", // HF Space endpoint
      'Legal-Pro': "https://consequential-wettable-danika.ngrok-free.dev/generate",
      'Contract-AI': "https://consequential-wettable-danika.ngrok-free.dev/generate",
      'LitAssist': "https://consequential-wettable-danika.ngrok-free.dev/generate"
    };

    const API_URL = modelEndpoints[model] || modelEndpoints['LAWGPT-4'];

    console.log(`🔄 Sending request to: ${API_URL} for model: ${model}`);
    console.log("📤 Message:", message);

    let body;

    if (model === 'LAWGPT-3.5') {
      // --- 1. Tokenize input message before sending ---
      const input_ids = await encodeMessageForLawGPT(message);

      body = {
        input_ids: input_ids,
        max_length: 200
      };
    } else {
      // Plain text for other models
      body = {
        query: message,
        model: model
      };
    }

    // --- 2. Send request to API ---
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "ngrok-skip-browser-warning": "true"
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("❌ Error response:", errorText);
      throw new Error(`Server error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const promptText = data.text;
    let generatedText = data.generated_text;
    if (generatedText.startsWith(promptText)) {
      generatedText = generatedText.slice(promptText.length).trim();
    }
    // --- 3. Process response ---
    if (!data) throw new Error("No response from AI model");

    return generatedText;

  } catch (error) {
    console.error("❌ generateBotResponse Error:", error);
    if (error.message.includes("Failed to fetch")) {
      return "⚠️ Cannot connect to AI server. Please check if the server is running.";
    }
    return `⚠️ Sorry, I could not process your request: ${error.message}`;
  }
};


export const getUserSessions = async (req, res) => {
  try {
    const userId = req.user.id;
    const sessions = await ChatSession.find({ userId: userId })
      .sort({ updatedAt: -1 })
      .select("-__v")
      .lean();

    res.status(200).json(sessions);
  } catch (error) {
    console.error("❌ getUserSessions Error:", error);
    res.status(500).json({ error: error.message });
  }
};

// Delete a session
export const deleteSession = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    console.log(`🗑️  Attempting to delete session ${id} for user ${userId}`);

    const result = await ChatSession.findOneAndDelete({
      _id: id,
      userId: userId
    });

    if (!result) {
      console.log(`❌ Session ${id} not found for user ${userId}`);
      return res.status(404).json({ error: "Session not found" });
    }

    console.log(`✅ Session ${id} deleted successfully`);

    // Decrement user's totalChats count if it's greater than 0
    try {
      // First get current count
      const user = await User.findById(userId);
      const currentCount = user ? user.totalChats : 0;
      const newCount = Math.max(0, currentCount - 1);

      await User.findByIdAndUpdate(userId, {
        $set: { totalChats: newCount }
      });

      console.log(`📊 User ${userId} totalChats updated: ${currentCount} -> ${newCount}`);
    } catch (updateError) {
      console.error(`❌ Error updating user totalChats for user ${userId}:`, updateError);
      // Don't fail the deletion if updating totalChats fails
    }

    res.status(200).json({ message: "Session deleted successfully" });
  } catch (error) {
    console.error("❌ deleteSession Error:", error);
    res.status(500).json({ error: error.message });
  }
};

// Create a new session explicitly
export const createNewSession = async (req, res) => {
  try {
    const userId = req.user.id;
    const { title } = req.body;

    const session = new ChatSession({
      userId: userId,
      title: title || "New Legal Consultation",
      messages: [
        {
          sender: "bot",
          message: "Hello! I'm LAWGPT, your AI legal assistant. How can I help you with legal questions today?",
          timestamp: new Date()
        }
      ]
    });

    await session.save();

    // Increment user's totalChats count
    try {
      await User.findByIdAndUpdate(userId, { $inc: { totalChats: 1 } });
      console.log(`📊 User ${userId} totalChats incremented for explicit new session`);
    } catch (countError) {
      console.error(`❌ Error incrementing totalChats for user ${userId}:`, countError);
      // Don't fail session creation if updating totalChats fails
    }

    res.status(201).json({
      _id: session._id,
      title: session.title,
      messages: session.messages,
      createdAt: session.createdAt,
      updatedAt: session.updatedAt
    });
  } catch (error) {
    console.error("❌ createNewSession Error:", error);
    res.status(500).json({ error: error.message });
  }
};

// Update session title
export const updateSession = async (req, res) => {
  try {
    const { id } = req.params;
    const { title } = req.body;
    const userId = req.user.id;

    console.log(`✏️  Attempting to update session ${id} title to '${title}' for user ${userId}`);

    if (!title || title.trim() === '') {
      return res.status(400).json({ error: 'Title is required' });
    }

    const session = await ChatSession.findOne({
      _id: id,
      userId: userId
    });

    if (!session) {
      console.log(`❌ Session ${id} not found for user ${userId}`);
      return res.status(404).json({ error: 'Session not found' });
    }

    session.title = title.trim();
    session.updatedAt = new Date();

    await session.save();

    console.log(`✅ Session ${id} title updated successfully to '${title}'`);

    res.status(200).json({
      _id: session._id,
      title: session.title,
      updatedAt: session.updatedAt
    });
  } catch (error) {
    console.error('❌ updateSession Error:', error);
    res.status(500).json({ error: error.message });
  }
};
