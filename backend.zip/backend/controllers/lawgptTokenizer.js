import fetch from 'node-fetch';

// Call Python tokenizer server to get input_ids

export const encodeMessageForLawGPT = async (message) => {
  const TOKENIZER_URL = "http://127.0.0.1:5005/tokenize";

  const messages = [
    {
      role: "system",
      content: `You are LawGPT. Respond in clear professional language using short bullet points when possible.
                Use emojis to improve readability:
                🧩 Concept / Idea
                ⚖ Law / Legal principle
                🔍 Research / Case references
                📄 Document / Contract
                ⚠ Risk / Warning
                🏛 Court / Judgment
                💡 Advice / Recommendation
                1️⃣, 2️⃣, 3️⃣ for numbered steps`
    },
    { role: "user", content: message }
  ];

  const res = await fetch(TOKENIZER_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages })
  });

  if (!res.ok) throw new Error(await res.text());

  const data = await res.json();
  return data.input_ids; // array of token IDs
};

