from flask import Flask, request, jsonify
from transformers import AutoTokenizer
from huggingface_hub import login

app = Flask(__name__)

login("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")
tokenizer = AutoTokenizer.from_pretrained("google/gemma-3-1b-it")

@app.route("/tokenize", methods=["POST"])
def tokenize():
    data = request.get_json()
    messages = data.get("messages", [])
    prompt_text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    input_ids = tokenizer.encode(prompt_text)
    return jsonify({"input_ids": input_ids})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5005)
