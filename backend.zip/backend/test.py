from transformers import AutoTokenizer
import requests

SPACE_URL = "https://abhinav777-77-head.hf.space/generate_from_ids"
tokenizer = AutoTokenizer.from_pretrained("google/gemma-3-1b-it")


# --- 2. Query the database ---
from huggingface_hub import login
login("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")
# query = "Which IPC section deals with murder and its punishment?"

messages = [
    {"role": "system", "content": """
            You are LawGPT. Respond in clear professional language using short bullet points when possible.
            Use emojis to improve readability:
            🧩 Concept / Idea
            ⚖ Law / Legal principle
            🔍 Research / Case references
            📄 Document / Contract
            ⚠ Risk / Warning
            🏛 Court / Judgment
            💡 Advice / Recommendation
            1️⃣, 2️⃣, 3️⃣ for numbered steps
            """},
    {"role": "user", "content": "Which IPC section deals with murder and its punishment?"}
]

# ✅ Apply chat template
prompt_text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,  # we only want the formatted string
    add_generation_prompt=True  # adds the <start_of_turn>model marker
)
input_ids = tokenizer.encode(prompt_text)

response = requests.post(SPACE_URL, json={"input_ids": input_ids, "max_length": 200})
generated_text=response.json()["generated_text"]
prompt_len = len(tokenizer.decode(input_ids, skip_special_tokens=True))
final_output = generated_text[prompt_len:].strip()
print(final_output)